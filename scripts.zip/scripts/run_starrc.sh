#!/bin/sh
## corner list 
#  cmax_125 cmax_-40 rcmax_125 rcmax_-40 rcmin_125 rcmin_-40 cmin_125 cmin_-40 tt_0
# Usage:    ./run_starrc.sh  "corner list"  "mw cell name" [parallel jobs num]
#  ex1:	./run_starrc.sh cmax_125  cpu_top
#  ex2: ./run_starrc.sh "cmax_125 cmin_-40"  cpu_top
#  ex3: ./run_starrc.sh max    cpu_top  ---- run only whole max corners
#  ex4  ./run_starrc.sh  all cpu_top   4 ---each time run 4 jobs till complete
##   nxtgrd file 
cmax="/pub/lib/tsmc28hpc/rc_tech/star_rcxt/1p8m5x2z/cworst/cln28hpm_1p08m+ut-alrdl_5x2z_cworst.nxtgrd"
cmin="/pub/lib/tsmc28hpc/rc_tech/star_rcxt/1p8m5x2z/cbest/cln28hpm_1p08m+ut-alrdl_5x2z_cbest.nxtgrd"
rcmax="/pub/lib/tsmc28hpc/rc_tech/star_rcxt/1p8m5x2z/rcworst/cln28hpm_1p08m+ut-alrdl_5x2z_rcworst.nxtgrd"
rcmin="/pub/lib/tsmc28hpc/rc_tech/star_rcxt/1p8m5x2z/rcbest/cln28hpm_1p08m+ut-alrdl_5x2z_rcbest.nxtgrd"
tt="/pub/lib/tsmc28hpc/rc_tech/star_rcxt/1p8m5x2z/typical/cln28hpm_1p08m+ut-alrdl_5x2z_typical.nxtgrd"
map="/beproj1/zx298200/cot/archive_zx298200/zx298200_idp/sub_proj/lb_gpu_top/lib/tech/TSMC28HPC_1P8M_5X2UTZRDL.star2MW.map"

## starrc option value  and run cmd #{{{
starrc_cmd="
MILKYWAY_DATABASE: 
BLOCK:
MAPPING_FILE: 
TCAD_GRD_FILE: 
OPERATING_TEMPERATURE:
NETLIST_FILE: 
NETLIST_FORMAT: SPEF
COUPLE_TO_GROUND: NO
COUPLING_MULTIPLIER:             1
COUPLING_THRESHOLD_OPERATION : AND
COUPLING_ABS_THRESHOLD:          5e-16
COUPLING_REL_THRESHOLD:          0.03
DENSITY_BASED_THICKNESS:         YES
EXTRACTION:                      RC
EXTRACT_VIA_CAPS:                YES
HIERARCHICAL_SEPARATOR:          /
MODE:                            400
REDUCTION:                       TOPOLOGICAL
REMOVE_FLOATING_NETS:            NO
REMOVE_DANGLING_NETS:            NO
MILKYWAY_ADDITIONAL_VIEWS: FILL
METAL_FILL_POLYGON_HANDLING:     FLOATING
MAGNIFICATION_FACTOR:            0.9
MAGNIFY_DEVICE_PARAMS:           NO
NETLIST_COMPRESS_COMMAND: gzip -q -f
NUM_CORES: 8
"
run='/pub/tools/synopsys/starrc_2014.12_SP2/bin/StarXtract -clean $1 &
/pub/tools/synopsys/starrc_2014.12_SP2/bin/StarXtract -clean $1 &
/pub/tools/synopsys/starrc_2014.12_SP2/bin/StarXtract -clean $1 &
/pub/tools/synopsys/starrc_2014.12_SP2/bin/StarXtract -clean $1 &
/pub/tools/synopsys/starrc_2014.12_SP2/bin/StarXtract -clean $1 &
/pub/tools/synopsys/starrc_2014.12_SP2/bin/StarXtract -clean $1 &
/pub/tools/synopsys/starrc_2014.12_SP2/bin/StarXtract -clean $1 &
/pub/tools/synopsys/starrc_2014.12_SP2/bin/StarXtract -clean $1 '
#### #}}}

mdb=$(pwd)/$(echo *.mw)   # get milkyway data base
corners=$1   # get corner 
cell=$2     # get cell 
job_num=$3  ; #  get parallel job num  default one
if [[ $job_num -le 0 ]] 
then 
	job_num=1 ; #  default 1
fi
if [[ "$1" == "all" ]] 
then
	corners="cmin_125 cmin_-40 cmax_125 cmax_-40 rcmax_125 rcmax_-40 rcmin_125 rcmin_-40   tt_25"
elif [[ "$1" == "max" ]] ; then 
	corners="cmax_125 cmax_-40 rcmax_125 rcmax_-40 "
elif [[ "$1" == "min" ]] ; then 
	corners="rcmin_125 rcmin_-40  cmin_125 cmin_-40  tt_25"
fi
####  run starrc on provided corner
i=1
for corner in $corners ; do 
		read nxtgrd temper <<< $(echo $corner | sed 's/_/ /')  #  get nxgrd file and temperature
		if [[ $temper < 0 ]] ; then corner=${nxtgrd}_n$(expr 0 - $temper); fi 
		eval nxtgrd=\$$nxtgrd  # get real nxgrd file
		dir=starrc_$corner   #  directory to run starrc and store spef file
		cmd=${dir}_cmd   #   starrc run option value file
		mkdir -p $dir
		cd $dir
		# generate starrc cmd  and run
		echo "$starrc_cmd" |sed -e '/MILKYWAY_DATABASE/ s#$# '${mdb}'#' \
				-e '/BLOCK/ s/$/ '${cell}'/' \
				-e '/MAPPING_FILE/ s#$# '${map}'#'  \
				-e '/TCAD_GRD_FILE/ s#$# '${nxtgrd}'#' \
				-e '/OPERATING_TEMPERATURE/ s#$# '${temper}'#' \
				-e '/NETLIST_FILE/ s#$# '${cell}'_'${corner}'.spef.gz#'  > $cmd
		if [[  $i%$job_num -eq 0 ]] 
		then 
            bsub -Ip /bin/sh -c "$run" "" $cmd  ;  sleep 3m ; /bin/rm -rf ./star 
		else
			bsub -Ip /bin/sh -c "$run" "" $cmd  ;  sleep 3m ; /bin/rm -rf ./star &
		fi 
		(( i++ ))
		cd -
done



## vim:foldenable fdm=marker

