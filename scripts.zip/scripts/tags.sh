#!/bin/bash 
#echo $@
help() {
	cat <<eof
	Usage:
	$0	FILE1 FILE2 ...
	$0	-a FILE1 FILE2 ... ; append content to tags file
eof
}
is_append=0
TEMP=`getopt -o ah  -- "$@"`
if [ $? != 0 ] ; then echo "Terminating..." >&2 ; exit 1 ; fi

eval set -- "$TEMP"
while true ; do
		case "$1" in
				-a) is_append=1; shift ;;
				-h) help ; exit ;;
                --) shift ; break ;;
		esac
done

##### generate tagstmp file  #######
grep -n -H -E '^[^#]*#?\b(set|proc|_icc_macro|_icc_fill_parm)\b +\w+[^ ]*' $@ |
sed -r 's/([^:]+):([^:]+):.*\b(set|proc|_icc_macro|_icc_fill_parm)\b +(\w+[^ ]*).*/\4\t\1\t\2/' >tagstmp
if [[ $is_append > 0 ]]
then
		mv tags tags.bk -f
		awk '!a[$1$2]++' tags.bk tagstmp | LC_COLLATE=C sort  > tags
else
		awk '!a[$1$2]++' tagstmp |LC_COLLATE=C sort > tags
fi

\rm -rf tagstmp tags.bk  >& /dev/null


